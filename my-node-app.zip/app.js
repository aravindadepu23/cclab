const express = require('express');
const app = express();

const PORT = process.env.PORT || 3000;

// Home route
app.get('/', (req, res) => {
    res.send('Hello from Node.js on Elastic Beanstalk 🚀');
});

// About route
app.get('/about', (req, res) => {
    res.send('This is a sample Node.js app deployed on AWS!');
});

// Health check
app.get('/health', (req, res) => {
    res.status(200).send('OK');
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
